package com.main.JSON.Poactua;

public class Test {  
    public static void main(String[] args) {
        // Llamada al método para leer el json por consola
        System.out.println("-------LEEMOS FICHERO-------");
        System.out.println(Back.leerJson());
    

    

    

        
        //Volvemos a leer el fichero json para comprobar el cambio y leeomos el objeto:

        System.out.println("");
        System.out.println("Modificación fichero json "+Back.leerJson());
        
    
        
    }
    
    
    
    }
