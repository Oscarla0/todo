package com.main.JSON.Popelicula;

public class Test {  
    public static void main(String[] args) {
        // Llamada al método para leer el json por consola
        System.out.println("-------LEEMOS FICHERO-------");
        System.out.println(Back.leerJson());
    
        System.out.println("");
        System.out.println("Modificación fichero json "+Back.leerJson());
        
    
        
    }
    
    
    
    }
